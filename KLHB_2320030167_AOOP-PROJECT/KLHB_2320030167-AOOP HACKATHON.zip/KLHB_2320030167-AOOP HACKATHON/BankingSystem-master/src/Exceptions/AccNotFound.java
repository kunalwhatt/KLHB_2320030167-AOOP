package Exceptions;

public class AccNotFound extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AccNotFound(String s)
	{
		super(s);
	}

}
